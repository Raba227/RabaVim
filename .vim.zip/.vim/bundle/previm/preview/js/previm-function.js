function isShowHeader() {
return 1;
}

function getFileName() {
return "C:\\Nishimura\\network研修.md";
}

function getFileType() {
return "markdown";
}

function getLastModified() {
return "2017/12/11 (月) 16:37:53";
}

function getContent() {
return "## ネットワーク研修\nIPアドレス　ネットワーク内でコンピュータに割り当てられた住所\nMACアドレス　ネットワーク機器に割り当てられた住所{物理アドレス、不変}\nIPアドレスとの関連付けはDHCPサーバが処理\n\nInternet Protocol\nMedia Access Control\n\n## 引き継ぎ\nインターネットの発表に終止符を\n";
}
