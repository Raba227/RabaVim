function isShowHeader() {
return 1;
}

function getFileName() {
return "C:\\Nishimura\\Adobe_target.md";
}

function getFileType() {
return "markdown";
}

function getLastModified() {
return "2017/11/20 (月) 17:25:28";
}

function getContent() {
return "<script>\nwindow.atFeedData = {\n  //固定値項目\n  \"type\":\"software_catalog\",\n  \"inventory\":1000,\n  //PIM連携項目\n  \"id\":\"SW00000145\",\n  \"Name\":\"テラリア\",\n  \"thumbnailURL\":\"https:sce.scene7.com/is/image/playstation/jp0365cusa01616_00terraria00000001_jacket?$pkgL$\",\n  \"pageUrl\":\"http:localhost:4502/content/pscom/ja-jp/games/ps4/u/uat-natsuirohighschool-vr-ps4.html\",\n  \"softFormat\":\"PS4\",\n  \"categoryId\":\"アドベンチャー\",\n  \"categoryMaker\":\"モノづくりアクションアドベンチャー\",\n  \"ceroAge\":\"C\",\n  \"releasedate_display\":\"2015年2月19日\",\n  \"maker_display\":\"(株)スパイク・チュンソフト\",\n  \"psn\":\"対応\",\n  \"value\":2500,\n  //\"priceTaxIncl_display\":\"2,500円\",\n  //\"thumbnailURLS\":\"https:sce.scene7.com/is/image/playstation/jp0365cusa01616_00terraria00000001_jacket?$pkgS$\",\n  //\"softFormat_display\":\"PS4&reg;\",\n  //\"player_display\":\"1～4人（オンライン時：1～8人）\",\n  //\"accessories_services\":\"psplus,psn,psapp\",\n  //\"contentsIcon\":\"vio\",\n  //\"banner_imageURL_PC\":\"sce.scene7.com/is/image/playstation/vljs00067_banner\",\n  //\"sample\":false\n  };\n</script>";
}
